package com.example.contactagenda.db;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import com.controlsangre.sangre.R;



public class Pre_Modify extends AppCompatActivity {

    EditText modificar_input;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pre_modify);
        modificar_input = (EditText) findViewById(R.id.modificar_input);
        db = openOrCreateDatabase("List", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS List (_id INT,_name STRING, _surname STRING, _year INT,_telephone INT,_email STRING,_blood STRING);");

    }

    public void modificar_clicked(View view){
        String query = "SELECT * FROM " + "List" + " WHERE " + "_id" + " = " + modificar_input.getText().toString() + ";";
        Cursor c = db.rawQuery(query, null);
    if(c.moveToFirst()){
        Intent i = new Intent(this, Modify.class);
        modificar_input = (EditText) findViewById(R.id.modificar_input);
        i.putExtra("_id" , modificar_input.getText().toString());
        startActivity(i);
    }else{
        confirmacion();
    }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_pre_modificar, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public void confirmacion(){

        AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(this);
        dlgAlert.setMessage("Wrong ID");
        dlgAlert.setTitle("Alert!");
        dlgAlert.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //dismiss the dialog
                    }
                });
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }
}