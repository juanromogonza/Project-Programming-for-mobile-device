package com.example.contactagenda.db;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import com.controlsangre.sangre.R;


public class Search_Person extends AppCompatActivity {

    EditText inputSearch;
    SQLiteDatabase db;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_person);
        db = openOrCreateDatabase("List", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS List (_id INT,_name STRING, _surname STRING, _year INT,_telephone INT,_email STRING,_blood STRING);");






    }
    public void onClick(View view){
        Cursor c = db.rawQuery("SELECT * FROM List ORDER BY _name", null);
        if (c.moveToFirst()) {
            StringBuffer buffer = new StringBuffer();
            while (c.moveToNext()) {
                buffer.append( c.getString(0).toUpperCase() + " "+ c.getString(1) + " " +  c.getString(2) + " " +c.getString(3) +" "+c.getString(4) +" "+c.getString(5) +" "+c.getString(6)+ "\n");

            }
            AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(this);
            dlgAlert.setCancelable(true);
            dlgAlert.setTitle("Show List");
            dlgAlert.setMessage(buffer.toString());
            dlgAlert.show();
        }else{
            AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(this);
            dlgAlert.setMessage("Empty List");
            dlgAlert.setTitle("Show List");
            dlgAlert.setPositiveButton("Ok",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            //dismiss the dialog
                        }
                    });
            return;
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_buscar_persona, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}