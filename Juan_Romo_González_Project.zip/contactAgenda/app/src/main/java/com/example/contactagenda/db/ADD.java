package com.example.contactagenda.db;

import com.controlsangre.sangre.R;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import static android.database.sqlite.SQLiteDatabase.openOrCreateDatabase;


public class ADD extends AppCompatActivity {
    SQLiteDatabase db;
    EditText nombre_input;
    EditText apellido_input;
    EditText edad_input;
    EditText telefono_input;
    EditText email_input;
    EditText sangre_input;


int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        nombre_input = (EditText) findViewById(R.id.nombre_input);
        apellido_input = (EditText) findViewById(R.id.apellido_input);
        edad_input = (EditText) findViewById(R.id.edad_input);
        telefono_input = (EditText) findViewById(R.id.telefono_input);
        email_input = (EditText) findViewById(R.id.email_input);
        sangre_input = (EditText) findViewById(R.id.sangre_input);
        Intent i = getIntent(); // gets the previously created intent
        String stringid = i.getStringExtra("_id");
         id= Integer.parseInt(stringid);
        db = openOrCreateDatabase("List", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS List (_id INT,_name STRING, _surname STRING, _year INT,_telephone INT,_email STRING,_blood STRING);");

    }

    //Añade una Persona a la Base de Datos

    public void agregar_clicked(View view){

        Persona personas = new Persona(nombre_input.getText().toString(), apellido_input.getText().toString(), Integer.parseInt(edad_input.getText().toString()), telefono_input.getText().toString(), email_input.getText().toString(), sangre_input.getText().toString(),id );
        db.execSQL("INSERT INTO List VALUES('"+personas.get_id()+"','" + personas.get_nombre() +
                "','" + personas.get_apellido()+ "','" + personas.get_edad() + "','" + personas.get_telefono() + "','"+personas.get_email()+"','"+personas.get_tiposangre()+"');");

        Cursor c = db.rawQuery("SELECT * FROM List ORDER BY _name", null);

            confirmacion();


        limpiarcampos();
    }


    //Limpia los valores entrados para efectos de estetica
    public void limpiarcampos(){

        nombre_input.setText("");
        apellido_input.setText("");
        edad_input.setText("");
        telefono_input.setText("");
        email_input.setText("");
        sangre_input.setText("");

    }

    public void confirmacion(){

        AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(this);
        dlgAlert.setMessage("Has been added successfully!");
        dlgAlert.setTitle("Add person");
        dlgAlert.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //dismiss the dialog
                    }
                });
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }


    public void modificar_clicked(View view) {
    }
}