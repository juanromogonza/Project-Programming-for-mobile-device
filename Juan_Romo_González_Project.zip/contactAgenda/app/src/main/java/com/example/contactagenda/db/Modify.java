package com.example.contactagenda.db;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import com.controlsangre.sangre.R;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;


public class Modify extends AppCompatActivity {
    SQLiteDatabase db;
    EditText nombre_input;
    EditText apellido_input;
    EditText edad_input;
    EditText telefono_input;
    EditText email_input;
    EditText sangre_input;
    int idglobal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //Aqui se hace el retrieve de la base de datos tomando un valor que viene en el intent anterior

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);
        nombre_input = (EditText) findViewById(R.id.nombre_input);
        apellido_input = (EditText) findViewById(R.id.apellido_input);
        edad_input = (EditText) findViewById(R.id.edad_input);
        telefono_input = (EditText) findViewById(R.id.telefono_input);
        email_input = (EditText) findViewById(R.id.email_input);
        sangre_input = (EditText) findViewById(R.id.sangre_input);
        Intent i = getIntent(); // gets the previously created intent
        String stringid = i.getStringExtra("_id");
        int id= Integer.parseInt(stringid);
        db = openOrCreateDatabase("List", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS List (_id INT,_name STRING, _surname STRING, _year INT,_telephone INT,_email STRING,_blood STRING);");
        String query = "SELECT * FROM " + "List" + " WHERE " + "_id" + " = " + id + ";";
        Cursor c = db.rawQuery(query, null);

        if (c != null) {
            c.moveToFirst();
        }

        //Vuelve a rellenar los inputs con los valores del cursor
        nombre_input.setText(c.getString(c.getColumnIndexOrThrow("_name")));
        apellido_input.setText(c.getString(c.getColumnIndexOrThrow("_surname")));
        edad_input.setText(c.getString(c.getColumnIndexOrThrow("_year")));
        telefono_input.setText(c.getString(c.getColumnIndexOrThrow("_telephone")));
        email_input.setText(c.getString(c.getColumnIndexOrThrow("_email")));
        sangre_input.setText(c.getString(c.getColumnIndexOrThrow("_blood")));
        idglobal = c.getInt(c.getColumnIndexOrThrow("_id"));

    }

    public void modificar_clicked(View view){

        Persona persona = new Persona(nombre_input.getText().toString(), apellido_input.getText().toString(), Integer.parseInt(edad_input.getText().toString()), telefono_input.getText().toString(), email_input.getText().toString(), sangre_input.getText().toString(),idglobal );

        ContentValues values = new ContentValues();
        values.put("_name", persona.get_nombre());
        values.put("_surname", persona.get_apellido());
        values.put("_year", persona.get_edad());
        values.put("_telephone", persona.get_telefono());
        values.put("_email", persona.get_email());
        values.put("_blood", persona.get_tiposangre());
        db.update("List", values, "_id" + "= ?", new String[] { String.valueOf(persona.get_id())});
        db.close();
        confirmacion();
        limpiarcampos();


    }

    public void confirmacion(){

        AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(this);
        dlgAlert.setMessage("Has been successfully modified!");
        dlgAlert.setTitle("Add person");
        dlgAlert.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //dismiss the dialog
                    }
                });
        dlgAlert.setCancelable(true);
        dlgAlert.create().show();
    }

    //Limpia los valores entrados para efectos de estetica
    public void limpiarcampos(){

        nombre_input.setText("");
        apellido_input.setText("");
        edad_input.setText("");
        telefono_input.setText("");
        email_input.setText("");
        sangre_input.setText("");

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_modificar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}